public class Cliente extends Pessoa {
    Conta c;

    public Cliente(String nome, String cpf) {
        super();
    }
}
